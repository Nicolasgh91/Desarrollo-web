
* identikit y blog
* responsive
* diseno y semantica, usar la mayor cantidad de etiquetas posibles
* 5 publicaciones
* subir a GITHUB